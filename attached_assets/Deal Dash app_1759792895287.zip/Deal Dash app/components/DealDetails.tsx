import { useState } from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Separator } from './ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Textarea } from './ui/textarea';
import { 
  ArrowLeft, 
  Phone, 
  Mail, 
  Calendar, 
  CheckCircle, 
  Clock, 
  FileText,
  Plus,
  Filter,
  MessageSquare,
  User,
  Settings,
  ChevronDown,
  ExternalLink,
  DollarSign,
  Building,
  Target,
  TrendingUp,
  Activity
} from 'lucide-react';
import { Task } from './TaskCard';

interface Contact {
  name: string;
  role: 'Owner' | 'CFO' | 'Counsel' | 'M&A Director' | 'Investment Principal';
  email: string;
  phone: string;
}

interface Document {
  id: string;
  name: string;
  status: 'Draft' | 'Sent' | 'Signed';
  date: string;
}

interface ActivityItem {
  id: string;
  type: 'task' | 'meeting' | 'email' | 'doc' | 'buyer' | 'invoice' | 'system';
  title: string;
  description: string;
  date: string;
  assignee: string;
  status: 'completed' | 'pending' | 'upcoming';
}

interface BuyerMatch {
  id: string;
  company: string;
  contact: Contact;
  targetAcquisition: string;
  budget: string;
  status: 'Interested' | 'Evaluating' | 'Negotiating' | 'Declined';
}

interface DealDetailsProps {
  task: Task;
  onClose: () => void;
}

const getStageColor = (stage: string) => {
  switch (stage.toLowerCase()) {
    case 'onboarding': return 'bg-gray-100 text-gray-800';
    case 'valuation': return 'bg-yellow-100 text-yellow-800';
    case 'buyer matching': return 'bg-purple-100 text-purple-800';
    case 'due diligence': return 'bg-blue-100 text-blue-800';
    case 'sold': return 'bg-green-100 text-green-800';
    default: return 'bg-gray-100 text-gray-800';
  }
};

const getRoleColor = (role: string) => {
  switch (role) {
    case 'Owner': return 'bg-blue-100 text-blue-800';
    case 'CFO': return 'bg-green-100 text-green-800';
    case 'Counsel': return 'bg-purple-100 text-purple-800';
    default: return 'bg-gray-100 text-gray-800';
  }
};

// Mock data
const getMockDealData = (task: Task) => ({
  stage: 'Valuation',
  owner: task.assignee || 'Unassigned',
  ageInStage: '14 days',
  healthScore: 85,
  sde: '$1.8M',
  description: task.description,
  notes: 'Strong financials with consistent YoY growth. CEO very motivated to sell within next 6 months. Some concerns about customer concentration.',
  sellerContacts: [
    {
      name: 'John Mitchell',
      role: 'Owner' as const,
      email: 'john@company.com',
      phone: '+1 (555) 123-4567'
    },
    {
      name: 'Sarah Johnson',
      role: 'CFO' as const,
      email: 'sarah@company.com',
      phone: '+1 (555) 123-4568'
    },
    {
      name: 'Robert Legal',
      role: 'Counsel' as const,
      email: 'robert@legalfirm.com',
      phone: '+1 (555) 123-4569'
    }
  ],
  recentDocs: [
    { id: '1', name: 'Financial Statements 2023', status: 'Signed' as const, date: '2024-01-20' },
    { id: '2', name: 'Management Presentation', status: 'Sent' as const, date: '2024-01-18' },
    { id: '3', name: 'NDA Template', status: 'Draft' as const, date: '2024-01-15' }
  ],
  activities: [
    {
      id: '1',
      type: 'email' as const,
      title: 'Follow-up on financial questions',
      description: 'Sent email to CFO requesting clarification on Q4 numbers',
      date: '2024-01-22T14:30:00Z',
      assignee: task.assignee || 'Unassigned',
      status: 'completed' as const
    },
    {
      id: '2',
      type: 'meeting' as const,
      title: 'Management presentation',
      description: 'Video call with full leadership team to present company overview',
      date: '2024-01-22T10:00:00Z',
      assignee: task.assignee || 'Unassigned',
      status: 'completed' as const
    },
    {
      id: '3',
      type: 'doc' as const,
      title: 'Financial statements uploaded',
      description: 'Received and processed 3-year financial statements',
      date: '2024-01-20T16:45:00Z',
      assignee: 'System',
      status: 'completed' as const
    },
    {
      id: '4',
      type: 'task' as const,
      title: 'Prepare buyer list',
      description: 'Research and compile list of strategic and financial buyers',
      date: '2024-01-25T09:00:00Z',
      assignee: task.assignee || 'Unassigned',
      status: 'upcoming' as const
    },
    {
      id: '5',
      type: 'meeting' as const,
      title: 'Buyer introductions',
      description: 'Initial calls with top 3 strategic buyers',
      date: '2024-01-30T14:00:00Z',
      assignee: task.assignee || 'Unassigned',
      status: 'upcoming' as const
    }
  ],
  buyerMatches: [
    {
      id: '1',
      company: 'TechCorp Industries',
      contact: {
        name: 'Michael Chen',
        role: 'M&A Director' as const,
        email: 'mchen@techcorp.com',
        phone: '+1 (555) 987-6543'
      },
      targetAcquisition: '100%',
      budget: '$8M - $12M',
      status: 'Evaluating' as const
    },
    {
      id: '2',
      company: 'Growth Capital Partners',
      contact: {
        name: 'Lisa Williams',
        role: 'Investment Principal' as const,
        email: 'lwilliams@growthcap.com',
        phone: '+1 (555) 987-6544'
      },
      targetAcquisition: '75%',
      budget: '$6M - $10M',
      status: 'Interested' as const
    },
    {
      id: '3',
      company: 'Strategic Ventures',
      contact: {
        name: 'David Park',
        role: 'M&A Director' as const,
        email: 'dpark@strategic.com',
        phone: '+1 (555) 987-6545'
      },
      targetAcquisition: '100%',
      budget: '$7M - $11M',
      status: 'Negotiating' as const
    }
  ]
});

export function DealDetails({ task, onClose }: DealDetailsProps) {
  const [showDrawer, setShowDrawer] = useState(false);
  const [drawerContent, setDrawerContent] = useState<'buyers' | null>(null);
  const [notesExpanded, setNotesExpanded] = useState(false);
  const [activeFilter, setActiveFilter] = useState<string>('all');

  const dealData = getMockDealData(task);

  const openBuyerMatches = () => {
    setDrawerContent('buyers');
    setShowDrawer(true);
  };

  const closeDrawer = () => {
    setShowDrawer(false);
    setDrawerContent(null);
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'task': return CheckCircle;
      case 'meeting': return Calendar;
      case 'email': return Mail;
      case 'doc': return FileText;
      case 'buyer': return Building;
      case 'invoice': return DollarSign;
      case 'system': return Settings;
      default: return Activity;
    }
  };

  const filteredActivities = dealData.activities.filter(activity => {
    if (activeFilter === 'all') return true;
    return activity.type === activeFilter;
  });

  return (
    <div className="h-full flex flex-col relative">
      {/* Sticky Header */}
      <div className="sticky top-0 z-20 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" onClick={onClose}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Pipeline
              </Button>
              <div className="text-sm text-muted-foreground">•</div>
              <h1>{task.title}</h1>
              <Badge className={getStageColor(dealData.stage)}>
                {dealData.stage}
              </Badge>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <User className="h-4 w-4" />
                {dealData.owner}
              </div>
            </div>
          </div>
        </div>

        {/* Command Bar */}
        <div className="px-6 py-3 border-t bg-muted/30">
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Calendar className="h-4 w-4 mr-2" />
              Schedule
            </Button>
            <Button variant="outline" size="sm">
              <FileText className="h-4 w-4 mr-2" />
              Send for Signature
            </Button>
            <Button variant="outline" size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Add Doc
            </Button>
            <Button variant="outline" size="sm">
              <DollarSign className="h-4 w-4 mr-2" />
              Create Invoice
            </Button>
            <Button variant="outline" size="sm">
              <TrendingUp className="h-4 w-4 mr-2" />
              Update Stage
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden flex">
        {/* Left Column - Overview */}
        <div className="w-96 border-r overflow-y-auto bg-background">
          <div className="p-6 space-y-6">
            {/* Deal Snapshot */}
            <Card className="p-4">
              <h3 className="mb-4">Deal Snapshot</h3>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="text-sm text-muted-foreground">Revenue</label>
                  <p className="text-green-600">{task.revenue}</p>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground">SDE</label>
                  <p>{dealData.sde}</p>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground">Valuation</label>
                  <p>$8.5M - $12.0M</p>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground">Multiple</label>
                  <p>4.1x</p>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground">Commission</label>
                  <p>3.5%</p>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground">Age in Stage</label>
                  <p>{dealData.ageInStage}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <label className="text-sm text-muted-foreground">Health Score</label>
                <div className="flex-1 bg-muted rounded-full h-2">
                  <div 
                    className="bg-green-600 h-2 rounded-full"
                    style={{ width: `${dealData.healthScore}%` }}
                  />
                </div>
                <span className="text-sm text-green-600">{dealData.healthScore}%</span>
              </div>
            </Card>

            {/* Description */}
            <div>
              <label className="text-sm text-muted-foreground mb-2 block">Description</label>
              <p className="text-sm leading-relaxed">{dealData.description}</p>
            </div>

            {/* Notes */}
            <Card className="p-4">
              <div className="flex items-center justify-between mb-2">
                <h4>Notes</h4>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => setNotesExpanded(!notesExpanded)}
                >
                  <ChevronDown className={`h-4 w-4 transition-transform ${notesExpanded ? 'rotate-180' : ''}`} />
                </Button>
              </div>
              {notesExpanded && (
                <div className="space-y-3">
                  <p className="text-sm text-muted-foreground">{dealData.notes}</p>
                  <Textarea placeholder="Add a note..." className="min-h-20" />
                  <Button size="sm">Add Note</Button>
                </div>
              )}
            </Card>

            {/* Seller Contacts */}
            <div>
              <h4 className="mb-3">Seller Contacts</h4>
              <div className="space-y-3">
                {dealData.sellerContacts.map((contact, index) => (
                  <Card key={index} className="p-3">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-medium">{contact.name}</p>
                        <Badge variant="outline" className={`text-xs ${getRoleColor(contact.role)}`}>
                          {contact.role}
                        </Badge>
                      </div>
                      <div className="flex gap-1">
                        <Button variant="outline" size="sm">
                          <Mail className="h-3 w-3" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Phone className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>

            {/* Docs Summary */}
            <Card className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h4>Recent Documents</h4>
                <Button variant="ghost" size="sm">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  View all
                </Button>
              </div>
              <div className="space-y-2">
                {dealData.recentDocs.map((doc) => (
                  <div key={doc.id} className="flex items-center justify-between p-2 rounded hover:bg-muted/50">
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">{doc.name}</span>
                    </div>
                    <Badge 
                      variant="outline" 
                      className={`text-xs ${
                        doc.status === 'Signed' ? 'bg-green-100 text-green-800' :
                        doc.status === 'Sent' ? 'bg-blue-100 text-blue-800' :
                        'bg-gray-100 text-gray-800'
                      }`}
                    >
                      {doc.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>

        {/* Middle Column - Activity Timeline */}
        <div className="flex-1 overflow-y-auto bg-background">
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2>Activity Timeline</h2>
              <div className="flex items-center gap-2">
                <Select value={activeFilter} onValueChange={setActiveFilter}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="task">Tasks</SelectItem>
                    <SelectItem value="email">Emails</SelectItem>
                    <SelectItem value="meeting">Meetings</SelectItem>
                    <SelectItem value="doc">Docs</SelectItem>
                    <SelectItem value="system">System</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={openBuyerMatches} variant="outline" size="sm">
                  <Target className="h-4 w-4 mr-2" />
                  Buyer Matches
                </Button>
              </div>
            </div>

            <div className="space-y-4">
              {filteredActivities.map((activity) => {
                const IconComponent = getActivityIcon(activity.type);
                return (
                  <Card key={activity.id} className="p-4">
                    <div className="flex items-start gap-3">
                      <IconComponent 
                        className={`h-5 w-5 mt-0.5 flex-shrink-0 ${
                          activity.status === 'completed' ? 'text-green-600' :
                          activity.status === 'pending' ? 'text-orange-500' :
                          'text-blue-500'
                        }`} 
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-2">
                          <h4>{activity.title}</h4>
                          <div className="flex items-center gap-2">
                            <Badge 
                              variant="outline"
                              className={`text-xs ${
                                activity.status === 'completed' ? 'bg-green-100 text-green-800' :
                                activity.status === 'pending' ? 'bg-orange-100 text-orange-800' :
                                'bg-blue-100 text-blue-800'
                              }`}
                            >
                              {activity.status}
                            </Badge>
                            {activity.status !== 'completed' && (
                              <Button variant="ghost" size="sm">
                                <Settings className="h-3 w-3" />
                              </Button>
                            )}
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">{activity.description}</p>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {new Date(activity.date).toLocaleDateString()}
                          </span>
                          <span>Assigned: {activity.assignee}</span>
                        </div>
                        {activity.status !== 'completed' && (
                          <div className="flex items-center gap-2 mt-3">
                            <Button variant="outline" size="sm">
                              <CheckCircle className="h-3 w-3 mr-1" />
                              Mark Done
                            </Button>
                            <Button variant="outline" size="sm">
                              <MessageSquare className="h-3 w-3 mr-1" />
                              Comment
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>

            <Card className="p-4 mt-6">
              <div className="flex items-center gap-3">
                <Plus className="h-5 w-5 text-muted-foreground" />
                <div className="flex-1">
                  <Textarea placeholder="Add a new task..." className="min-h-20" />
                  <div className="flex justify-end gap-2 mt-2">
                    <Button variant="outline" size="sm">Cancel</Button>
                    <Button size="sm">Add Task</Button>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>

      {/* Context Drawer */}
      {showDrawer && (
        <>
          <div 
            className="fixed inset-0 bg-black/50 z-30"
            onClick={closeDrawer}
          />
          <div className="fixed right-0 top-0 h-full w-96 bg-background border-l z-40 overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2>Buyer Matches</h2>
                <Button variant="ghost" size="sm" onClick={closeDrawer}>
                  ✕
                </Button>
              </div>

              <div className="space-y-4">
                {dealData.buyerMatches.map((buyer) => (
                  <Card key={buyer.id} className="p-4">
                    <div className="space-y-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4>{buyer.company}</h4>
                          <p className="text-sm text-muted-foreground">{buyer.contact.name}</p>
                          <Badge variant="outline" className="text-xs mt-1">
                            {buyer.contact.role}
                          </Badge>
                        </div>
                        <Badge 
                          className={`${
                            buyer.status === 'Negotiating' ? 'bg-green-100 text-green-800' :
                            buyer.status === 'Evaluating' ? 'bg-blue-100 text-blue-800' :
                            buyer.status === 'Interested' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-gray-100 text-gray-800'
                          }`}
                        >
                          {buyer.status}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <label className="text-muted-foreground">Target Acquisition</label>
                          <p>{buyer.targetAcquisition}</p>
                        </div>
                        <div>
                          <label className="text-muted-foreground">Budget</label>
                          <p>{buyer.budget}</p>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          <Mail className="h-3 w-3 mr-1" />
                          Email
                        </Button>
                        <Button variant="outline" size="sm" className="flex-1">
                          <Calendar className="h-3 w-3 mr-1" />
                          Schedule
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              <div className="mt-6 space-y-3">
                <Button className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Buyer
                </Button>
                <Button variant="outline" className="w-full">
                  <FileText className="h-4 w-4 mr-2" />
                  Send DocuSign
                </Button>
                <Button variant="outline" className="w-full">
                  <Settings className="h-4 w-4 mr-2" />
                  Edit Deal
                </Button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}