import { useDrag } from 'react-dnd';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';

export interface Task {
  id: string;
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high';
  assignee?: string;
  tags?: string[];
  createdAt: string;
  revenue?: string;
  timeToNextStep?: string;
  touches?: number;
}

interface TaskCardProps {
  task: Task;
  onCardClick?: (task: Task) => void;
}

export function TaskCard({ task, onCardClick }: TaskCardProps) {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: 'task',
    item: { id: task.id },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  }));

  const priorityColors = {
    low: 'bg-green-100 text-green-800 border-green-200',
    medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    high: 'bg-red-100 text-red-800 border-red-200',
  };

  return (
    <Card
      ref={drag}
      className={`p-4 mb-3 cursor-move transition-all duration-200 hover:shadow-md ${
        isDragging ? 'opacity-50 rotate-2 scale-105' : ''
      }`}
    >
      <div className="space-y-3 cursor-pointer" onClick={() => {
        onCardClick?.(task);
      }}>
        <div className="flex items-start justify-between gap-2">
          <h3 className="line-clamp-2">{task.title}</h3>
          <Badge
            variant="outline"
            className={`text-xs ${priorityColors[task.priority]} capitalize`}
          >
            {task.priority}
          </Badge>
        </div>
        
        {task.description && (
          <p className="text-sm text-muted-foreground line-clamp-3">
            {task.description}
          </p>
        )}
        
        {task.tags && task.tags.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {task.tags.map((tag) => (
              <Badge key={tag} variant="secondary" className="text-xs">
                {tag}
              </Badge>
            ))}
          </div>
        )}
        
        {task.revenue && (
          <div className="flex items-center justify-between text-sm">
            <span>Revenue:</span>
            <span className="font-medium text-green-600">{task.revenue}</span>
          </div>
        )}
        
        {task.timeToNextStep && (
          <div className="flex items-center justify-between text-sm">
            <span>Next Step:</span>
            <span className="text-muted-foreground">{task.timeToNextStep}</span>
          </div>
        )}
        
        {task.touches !== undefined && (
          <div className="flex items-center justify-between text-sm">
            <span>Touches:</span>
            <span className="text-muted-foreground">{task.touches}</span>
          </div>
        )}
        
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">
            {new Date(task.createdAt).toLocaleDateString()}
          </span>
          {task.assignee && (
            <Avatar className="h-6 w-6">
              <AvatarFallback className="text-xs">
                {task.assignee.split(' ').map(n => n[0]).join('').toUpperCase()}
              </AvatarFallback>
            </Avatar>
          )}
        </div>
      </div>
    </Card>
  );
}