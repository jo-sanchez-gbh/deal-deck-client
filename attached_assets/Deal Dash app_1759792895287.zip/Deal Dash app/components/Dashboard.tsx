import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { ArrowLeft, TrendingUp, Clock, Users, DollarSign } from 'lucide-react';

interface DashboardProps {
  onBack: () => void;
}

interface DealData {
  id: string;
  title: string;
  stage: string;
  revenue: string;
  touches: number;
  createdAt: string;
  timeToNextStep: string;
}

// Sample data - in a real app, this would come from props or API
const sampleDeals: DealData[] = [
  {
    id: '1',
    title: 'TechFlow Industries',
    stage: 'Onboarding',
    revenue: '$2.8M ARR',
    touches: 12,
    createdAt: '2024-01-15',
    timeToNextStep: '3 days',
  },
  {
    id: '2',
    title: 'GreenTech Solutions',
    stage: 'Onboarding',
    revenue: '$1.2M ARR',
    touches: 8,
    createdAt: '2024-01-14',
    timeToNextStep: '1 week',
  },
  {
    id: '3',
    title: 'DataVault Corp',
    stage: 'Onboarding',
    revenue: '$950K ARR',
    touches: 5,
    createdAt: '2024-01-13',
    timeToNextStep: '2 weeks',
  },
  {
    id: '4',
    title: 'CloudPay Systems',
    stage: 'Valuation',
    revenue: '$4.5M ARR',
    touches: 18,
    createdAt: '2024-01-12',
    timeToNextStep: '5 days',
  },
  {
    id: '5',
    title: 'MedConnect Inc',
    stage: 'Valuation',
    revenue: '$3.1M ARR',
    touches: 15,
    createdAt: '2024-01-11',
    timeToNextStep: '1 week',
  },
  {
    id: '6',
    title: 'RetailBot Analytics',
    stage: 'Buyer Matching',
    revenue: '$6.2M ARR',
    touches: 22,
    createdAt: '2024-01-10',
    timeToNextStep: '3 days',
  },
  {
    id: '7',
    title: 'EduPlatform Pro',
    stage: 'Due Diligence',
    revenue: '$8.1M ARR',
    touches: 28,
    createdAt: '2024-01-09',
    timeToNextStep: '2 weeks',
  },
  {
    id: '8',
    title: 'LogiTrans Networks',
    stage: 'Sold',
    revenue: '$12.5M ARR',
    touches: 35,
    createdAt: '2024-01-08',
    timeToNextStep: 'Closed',
  },
  {
    id: '9',
    title: 'FoodieConnect',
    stage: 'Sold',
    revenue: '$5.7M ARR',
    touches: 24,
    createdAt: '2024-01-05',
    timeToNextStep: 'Closed',
  },
];

export function Dashboard({ onBack }: DashboardProps) {
  // Calculate metrics
  const totalDeals = sampleDeals.length;
  const totalRevenue = sampleDeals.reduce((acc, deal) => {
    const revenue = parseFloat(deal.revenue.replace(/[$,M]/g, ''));
    return acc + revenue;
  }, 0);

  const averageTouches = sampleDeals.reduce((acc, deal) => acc + deal.touches, 0) / totalDeals;

  // Group deals by stage
  const dealsByStage = sampleDeals.reduce((acc, deal) => {
    if (!acc[deal.stage]) {
      acc[deal.stage] = [];
    }
    acc[deal.stage].push(deal);
    return acc;
  }, {} as Record<string, DealData[]>);

  // Calculate average time in each stage (simplified - using days since creation)
  const getDaysInStage = (createdAt: string) => {
    const created = new Date(createdAt);
    const now = new Date();
    return Math.floor((now.getTime() - created.getTime()) / (1000 * 60 * 60 * 24));
  };

  const averageTimeByStage = Object.entries(dealsByStage).map(([stage, deals]) => {
    const avgTime = deals.reduce((acc, deal) => acc + getDaysInStage(deal.createdAt), 0) / deals.length;
    return { stage, averageTime: Math.round(avgTime), dealCount: deals.length };
  });

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="px-6 py-4 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={onBack}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Pipeline
            </Button>
            <div>
              <h1 className="text-2xl font-bold">Deal Dashboard</h1>
              <p className="text-muted-foreground">
                Overview of your deal pipeline performance
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Dashboard Content */}
      <div className="flex-1 overflow-auto p-6">
        <div className="grid gap-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Deals</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalDeals}</div>
                <p className="text-xs text-muted-foreground">
                  Across all pipeline stages
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">${totalRevenue.toFixed(1)}M</div>
                <p className="text-xs text-muted-foreground">
                  ARR across all deals
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Avg Touches</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{averageTouches.toFixed(1)}</div>
                <p className="text-xs text-muted-foreground">
                  Per deal across pipeline
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {((dealsByStage['Sold']?.length || 0) / totalDeals * 100).toFixed(1)}%
                </div>
                <p className="text-xs text-muted-foreground">
                  Deals closed successfully
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Pipeline Stage Analysis */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Deals by Stage</CardTitle>
                <CardDescription>
                  Distribution of deals across pipeline stages
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(dealsByStage).map(([stage, deals]) => (
                    <div key={stage} className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 rounded-full bg-primary"></div>
                        <span className="font-medium">{stage}</span>
                      </div>
                      <div className="text-right">
                        <div className="font-bold">{deals.length}</div>
                        <div className="text-sm text-muted-foreground">
                          {((deals.length / totalDeals) * 100).toFixed(1)}%
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Average Time in Stage</CardTitle>
                <CardDescription>
                  Days spent in each pipeline stage
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {averageTimeByStage.map(({ stage, averageTime, dealCount }) => (
                    <div key={stage} className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">{stage}</span>
                      </div>
                      <div className="text-right">
                        <div className="font-bold">{averageTime} days</div>
                        <div className="text-sm text-muted-foreground">
                          {dealCount} deal{dealCount !== 1 ? 's' : ''}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Deals</CardTitle>
              <CardDescription>
                Latest deals added to the pipeline
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {sampleDeals
                  .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                  .slice(0, 5)
                  .map((deal) => (
                    <div key={deal.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <div className="font-medium">{deal.title}</div>
                        <div className="text-sm text-muted-foreground">
                          {deal.stage} • {deal.revenue}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium">{deal.touches} touches</div>
                        <div className="text-xs text-muted-foreground">
                          {deal.timeToNextStep}
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
