import { useState } from 'react';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { KanbanColumn, Column } from './KanbanColumn';
import { Task } from './TaskCard';
import { Button } from './ui/button';
import { Settings, Filter, Plus, BarChart3 } from 'lucide-react';

const initialData: Column[] = [
  {
    id: 'onboarding',
    title: 'Onboarding',
    color: '#6b7280',
    tasks: [
      {
        id: '1',
        title: 'TechFlow Industries',
        description: 'SaaS platform for workflow automation in manufacturing',
        priority: 'high',
        assignee: 'Sarah Chen',
        tags: ['SaaS', 'Manufacturing'],
        createdAt: '2024-01-15',
        revenue: '$2.8M ARR',
        timeToNextStep: '3 days',
        touches: 12,
      },
      {
        id: '2',
        title: 'GreenTech Solutions',
        description: 'Renewable energy consulting and project management',
        priority: 'medium',
        assignee: 'Mike Rodriguez',
        tags: ['CleanTech', 'Consulting'],
        createdAt: '2024-01-14',
        revenue: '$1.2M ARR',
        timeToNextStep: '1 week',
        touches: 8,
      },
      {
        id: '3',
        title: 'DataVault Corp',
        description: 'Enterprise data security and compliance platform',
        priority: 'low',
        assignee: 'Alex Kim',
        tags: ['Security', 'Enterprise'],
        createdAt: '2024-01-13',
        revenue: '$950K ARR',
        timeToNextStep: '2 weeks',
        touches: 5,
      },
    ],
  },
  {
    id: 'valuation',
    title: 'Valuation',
    color: '#f59e0b',
    tasks: [
      {
        id: '4',
        title: 'CloudPay Systems',
        description: 'B2B payment processing with AI fraud detection',
        priority: 'high',
        assignee: 'Jennifer Walsh',
        tags: ['FinTech', 'B2B'],
        createdAt: '2024-01-12',
        revenue: '$4.5M ARR',
        timeToNextStep: '5 days',
        touches: 18,
      },
      {
        id: '5',
        title: 'MedConnect Inc',
        description: 'Telemedicine platform connecting rural communities',
        priority: 'medium',
        assignee: 'David Park',
        tags: ['HealthTech', 'B2C'],
        createdAt: '2024-01-11',
        revenue: '$3.1M ARR',
        timeToNextStep: '1 week',
        touches: 15,
      },
    ],
  },
  {
    id: 'buyer-matching',
    title: 'Buyer Matching',
    color: '#8b5cf6',
    tasks: [
      {
        id: '6',
        title: 'RetailBot Analytics',
        description: 'AI-powered inventory optimization for e-commerce',
        priority: 'medium',
        assignee: 'Lisa Thompson',
        tags: ['AI', 'E-commerce'],
        createdAt: '2024-01-10',
        revenue: '$6.2M ARR',
        timeToNextStep: '3 days',
        touches: 22,
      },
    ],
  },
  {
    id: 'due-diligence',
    title: 'Due Diligence',
    color: '#06b6d4',
    tasks: [
      {
        id: '7',
        title: 'EduPlatform Pro',
        description: 'Learning management system for corporate training',
        priority: 'high',
        assignee: 'Robert Singh',
        tags: ['EdTech', 'Enterprise'],
        createdAt: '2024-01-09',
        revenue: '$8.1M ARR',
        timeToNextStep: '2 weeks',
        touches: 28,
      },
    ],
  },
  {
    id: 'sold',
    title: 'Sold',
    color: '#10b981',
    tasks: [
      {
        id: '8',
        title: 'LogiTrans Networks',
        description: 'Supply chain visibility platform for logistics companies',
        priority: 'high',
        assignee: 'Amanda Foster',
        tags: ['Logistics', 'B2B'],
        createdAt: '2024-01-08',
        revenue: '$12.5M ARR',
        timeToNextStep: 'Closed',
        touches: 35,
      },
      {
        id: '9',
        title: 'FoodieConnect',
        description: 'Restaurant ordering and delivery management system',
        priority: 'medium',
        assignee: 'Carlos Martinez',
        tags: ['FoodTech', 'B2B'],
        createdAt: '2024-01-05',
        revenue: '$5.7M ARR',
        timeToNextStep: 'Closed',
        touches: 24,
      },
    ],
  },
];

interface KanbanBoardProps {
  onDealClick: (task: Task) => void;
  onDashboardClick: () => void;
}

export function KanbanBoard({ onDealClick, onDashboardClick }: KanbanBoardProps) {
  const [columns, setColumns] = useState<Column[]>(initialData);

  const handleTaskMove = (taskId: string, targetColumnId: string) => {
    setColumns(prevColumns => {
      const newColumns = [...prevColumns];
      
      // Find the task and its current column
      let task: Task | undefined;
      let sourceColumnIndex = -1;
      let taskIndex = -1;
      
      for (let i = 0; i < newColumns.length; i++) {
        const foundTaskIndex = newColumns[i].tasks.findIndex(t => t.id === taskId);
        if (foundTaskIndex !== -1) {
          task = newColumns[i].tasks[foundTaskIndex];
          sourceColumnIndex = i;
          taskIndex = foundTaskIndex;
          break;
        }
      }
      
      if (!task || sourceColumnIndex === -1) return prevColumns;
      
      // Find target column
      const targetColumnIndex = newColumns.findIndex(col => col.id === targetColumnId);
      if (targetColumnIndex === -1) return prevColumns;
      
      // Don't move if already in the same column
      if (sourceColumnIndex === targetColumnIndex) return prevColumns;
      
      // Remove task from source column
      newColumns[sourceColumnIndex].tasks.splice(taskIndex, 1);
      
      // Add task to target column
      newColumns[targetColumnIndex].tasks.push(task);
      
      return newColumns;
    });
  };

  const handleAddTask = (columnId: string) => {
    const newTask: Task = {
      id: `task-${Date.now()}`,
      title: 'New Company',
      description: 'Click to edit this deal',
      priority: 'medium',
      tags: [],
      createdAt: new Date().toISOString().split('T')[0],
      revenue: '$0 ARR',
      timeToNextStep: 'TBD',
      touches: 0,
    };

    setColumns(prevColumns =>
      prevColumns.map(column =>
        column.id === columnId
          ? { ...column, tasks: [...column.tasks, newTask] }
          : column
      )
    );
  };

  const totalTasks = columns.reduce((acc, column) => acc + column.tasks.length, 0);

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="h-full flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="flex items-center justify-between">
            <div>
              <h1>Deal Pipeline</h1>
              <p className="text-muted-foreground">
                {totalTasks} deals across {columns.length} stages
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={onDashboardClick}>
                <BarChart3 className="h-4 w-4 mr-2" />
                Dashboard
              </Button>
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                Revenue Range
              </Button>
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                Industry
              </Button>
              <Button variant="outline" size="sm">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                New Deal
              </Button>
            </div>
          </div>
        </div>

        {/* Kanban Board */}
        <div className="flex-1 overflow-x-auto">
          <div className="flex gap-6 p-6 h-full min-w-max">
            {columns.map((column) => (
              <KanbanColumn
                key={column.id}
                column={column}
                onTaskMove={handleTaskMove}
                onAddTask={handleAddTask}
                onDealClick={onDealClick}
              />
            ))}
          </div>
        </div>
      </div>
    </DndProvider>
  );
}