# Deal Dash App - Testing Setup

## Quick Test on CodeSandbox

1. Go to [CodeSandbox](https://codesandbox.io)
2. Click "Create Sandbox" → "Import from GitHub" or "Upload Files"
3. Upload all files from this project
4. The app should automatically start running

## What to Test

### Dashboard Navigation
1. Click the "Dashboard" button in the top-right of the pipeline view
2. Verify you see the dashboard with metrics
3. Click "Back to Pipeline" to return to the Kanban board

### Dashboard Features
- **Key Metrics**: Total deals, revenue, average touches, conversion rate
- **Pipeline Analysis**: Deal distribution by stage
- **Stage Timing**: Average days in each stage
- **Recent Activity**: Latest deals list

### Kanban Board
- Drag and drop deals between columns
- Click on deals to view details
- Add new deals using the "New Deal" button

## File Structure
```
Deal Dash app/
├── App.tsx                 # Main app with routing
├── main.tsx               # React entry point
├── index.html             # HTML template
├── package.json           # Dependencies
├── components/
│   ├── Dashboard.tsx      # New dashboard component
│   ├── KanbanBoard.tsx    # Pipeline view
│   ├── DealDetails.tsx    # Deal detail view
│   └── ui/               # UI components
└── styles/
    └── globals.css       # Tailwind styles
```

## Dependencies
- React 18
- TypeScript
- Tailwind CSS
- React DnD (drag and drop)
- Lucide React (icons)
