import { useState } from 'react';
import { KanbanBoard } from './components/KanbanBoard';
import { DealDetails } from './components/DealDetails';
import { Dashboard } from './components/Dashboard';
import { Task } from './components/TaskCard';

type View = 'kanban' | 'dashboard' | 'deal';

export default function App() {
  const [currentView, setCurrentView] = useState<View>('kanban');
  const [selectedDeal, setSelectedDeal] = useState<Task | null>(null);

  const handleDealClick = (task: Task) => {
    setSelectedDeal(task);
    setCurrentView('deal');
  };

  const handleBackToKanban = () => {
    setCurrentView('kanban');
    setSelectedDeal(null);
  };

  const handleDashboardClick = () => {
    setCurrentView('dashboard');
  };

  return (
    <div className="size-full">
      {currentView === 'deal' && selectedDeal ? (
        <DealDetails 
          task={selectedDeal} 
          onClose={handleBackToKanban} 
        />
      ) : currentView === 'dashboard' ? (
        <Dashboard onBack={handleBackToKanban} />
      ) : (
        <KanbanBoard 
          onDealClick={handleDealClick} 
          onDashboardClick={handleDashboardClick}
        />
      )}
    </div>
  );
}